# SLY Music — Android Studio project

This is the first Android app project for SLY Music. It packages the SLY Music web prototype inside a native Android WebView, with internet access and Android's file picker for selecting local audio files.

## Open and build
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio, choose **Open** and select the extracted `SLY_Music_Android` folder.
4. Allow Gradle to sync and install the Android SDK Platform 35 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. When the build finishes, use the APK link shown by Android Studio to install on your Android phone. You may need to allow installation from that source.

## Included
- SLY Music themed UI with Midnight, Light, Purple Haze and Ocean Blue themes
- Search for free-to-access audio in Internet Archive
- Android file picker for selecting local audio
- App icon and launcher setup
- Android internet permission

## Important limitations
- This ZIP is Android source code, not a prebuilt APK. It has not been compiled or tested on a device in this environment.
- The prototype's online search depends on Internet Archive's public API and direct audio files; availability and rights vary by item.
- Local tracks selected in this first prototype are session-based. Playlists and library persistence, background playback/lock-screen controls, downloads, and additional catalogues require further native implementation.
- Use only music you are legally allowed to stream or download.


## Build an APK in the cloud (no Android Studio needed on your phone)
This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`. To build the APK: create a GitHub repository, upload/commit the contents of this project to its root, open the repository's **Actions** tab, select **Build SLY Music APK**, and press **Run workflow**. When the run completes, open it and download the **SLY-Music-debug-APK** artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open that APK on your Android phone and allow installation from your browser/files app if prompted. The first cloud build needs internet access to download Gradle and Android dependencies.

The debug APK is for testing and personal installation; it is not a signed Play Store release.


## Android compatibility

- Minimum supported Android version: **Android 5.0 (API 21)**.
- Designed to build with Android SDK 35 and Java 17.
- Newer Android versions may apply their own system and WebView behavior; test on target devices before release.
